# -*- coding: utf-8 -*-
"""
A PROPER CODE
"""

import matplotlib.pyplot as plt
import math
import numpy as np
from data_access_funcs import load_signal_data

# THis analysis is for 07_Dec Session
from signal_dict_07_DEC import signals

"""
# Import SHot Class
import importlib.util
spec = importlib.util.spec_from_file_location("Name", r"C:/Users/Tomas/Imperial College London/Battle, Ronan - Shared MSci project/Scripts/Shot_Class.py")
foo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(foo)
foo.Shot()
"""

import sys
sys.path.append(r'C:\Users\Tomas\Imperial College London\Battle, Ronan - Shared MSci project\Scripts') # "/Users/Tomas/Imperial\ College London/Battle,\ Ronan\ -\ Shared\ MSci\ project/Scripts")
from Shot_Class_T import Shot


"""
class Shot():
    def __init__(self, ShotNumber):
#       must define signals dictionary here based on shot number/session series
        self.data = {} # initialise data dictionary
        self.ShotNumber = ShotNumber
        for sig in signals:
            try:
                fn = str(ShotNumber) + '_' + sig + '.p'
                self.data[sig] = load_signal_data(fn)
            except FileNotFoundError:
                pass
    
    def signals_present(self):
        return self.data.keys()
    
    def print_signal(self, SignalName):
        x,y = self.data[SignalName]['time'], self.data[SignalName]['data']
"""

#%%

s27769 = Shot(27769,signals)
s27769.print_signal('ADA_DALPHA_INVERTED')

        
        


